package com.paypal.training.portfolio;

public enum TradeAction {
	BUY, SALE
}
