package com.paypal.training;

import java.util.Date;

public class Payment {
	
	
	public Payment(float amt,Date payDate){
	}

	
   public Payment adjustPaymentAmount(float amt){
   }
}
