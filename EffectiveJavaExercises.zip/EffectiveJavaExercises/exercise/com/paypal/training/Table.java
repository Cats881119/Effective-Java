package com.paypal.training;

import java.util.HashMap;
import java.util.Map;

public class Table {

	private	int	number;
	private	int	numberOfSeats;
	static Map<Integer,Table> tableMap = new HashMap<Integer,Table>();

	
	public static Table	getTable(int number){
	}
	
	private	Table(int	number,	int	numberOfSeats){
		this.number = number;
		this.numberOfSeats = numberOfSeats;
	}
	
	public	int	getNumber(){
		return number;
	}
	public int	getNumberOfSeats(){
		return numberOfSeats;
	}

	@Override
	public String toString() {
		return "Table [number=" + number + ", numberOfSeats=" + numberOfSeats
				+ "]";
	}
	
}
