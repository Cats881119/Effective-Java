package com.paypal.training;

import java.util.Date;

public class Employee {
	
	private	String	employeeNumber;
	private	String	firstName;
	private	String	lastName;
	private	Date	dob;
	private	double salary;
	
	public Employee(){
		
	}

	 @Override
	public boolean equals(Object obj) {
	}
	 
	 
	@Override
	public String toString() {
		return "Employee [employeeNumber=" + employeeNumber + ", firstName="
				+ firstName + ", lastName=" + lastName + ", dob=" + dob
				+ ", salary=" + salary + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		return result;
	}


	public String getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(String employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	

}
