package com.paypal.training;

import java.util.ArrayList;
import java.util.Collection;

public class Stack<E> {
	int topIndex = -1; 
	ArrayList<E> stack;
	
	public Stack() {
	}

	public void push(E obj) {
	}

	public void pushAll(Collection<? extends E> src) {
	}
	
	public E pop() {
	}

	public void popAll(Collection<? super E> dst) {
		if(dst.size() == 0)
			return;
		if(isEmpty()){
			dst.add(pop());
		}
			
	}
	
	public boolean isEmpty() {
	}

	public int size() {
	}

	@Override
	public String toString() {
		return stack.toString();
	}
}