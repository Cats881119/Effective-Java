package com.paypal.training;

public interface EncryptionStrategy{
	String encrypt(String clearText);
}